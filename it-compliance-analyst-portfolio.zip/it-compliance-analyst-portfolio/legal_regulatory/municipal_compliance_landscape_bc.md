# Municipal Compliance Landscape – British Columbia (Example)

- **FIPPA (BC Freedom of Information and Protection of Privacy Act):** Personal information handling and breach notification obligations.
- **Local Government Act & Community Charter:** Records retention and council reporting considerations.
- **PIPEDA (if applicable):** For certain commercial activities.
- **Standards/Guidance:** BCSA, BCFed privacy guidance, and relevant federal cyber advisories.
> Verify applicability with your Privacy Officer and Legal Counsel.
