# Dashboard Requirements

**Audience:** SSC and executive leadership.  
**Data Sources:** SIEM, EDR, ticketing, patching tool, GRC tracker.  
**Views:** Monthly trend, thresholds, drill-down to owners.  
**Export:** PDF for SSC; CSV for analysis.
