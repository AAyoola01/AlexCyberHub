# Security Metrics & KPIs

- Patch compliance (% within SLA)
- Vulnerability backlog trend & age
- Phishing: fail rate, report rate, time-to-report
- IR: Mean Time to Detect/Respond (MTTD/MTTR)
- Access reviews: completion % and exceptions
- Backup success rate and restore test success
