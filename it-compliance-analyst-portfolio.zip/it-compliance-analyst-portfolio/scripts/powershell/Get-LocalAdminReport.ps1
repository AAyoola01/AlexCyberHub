<#
.SYNOPSIS
  Export local administrators from Windows endpoints for access review evidence.
#>
param(
  [Parameter(Mandatory=$false)]
  [string[]]$Computers = @("localhost"),
  [string]$OutFile = "local_admins.csv"
)
$results = @()
foreach ($c in $Computers) {
  try {
    $group = Get-LocalGroupMember -Group "Administrators" -ComputerName $c
    foreach ($m in $group) {
      $results += [pscustomobject]@{Computer=$c; Member=$m.Name; Type=$m.ObjectClass}
    }
  } catch {
    $results += [pscustomobject]@{Computer=$c; Member="ERROR: $($_.Exception.Message)"; Type="N/A"}
  }
}
$results | Export-Csv -NoTypeInformation -Path $OutFile
Write-Output "Wrote $OutFile"
