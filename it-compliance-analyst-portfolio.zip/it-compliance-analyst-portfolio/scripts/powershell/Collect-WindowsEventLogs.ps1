<#
.SYNOPSIS
  Collect key Security event IDs for SIEM gap analysis.
#>
param(
  [string]$LogName = "Security",
  [int[]]$EventIDs = @(4624,4625,4720,4728,4732,4738,4740,4723,4724),
  [string]$OutFile = "security_events.csv"
)
$events = Get-WinEvent -FilterHashtable @{LogName=$LogName; Id=$EventIDs} -MaxEvents 1000 |
  Select-Object TimeCreated, Id, LevelDisplayName, ProviderName, Message
$events | Export-Csv -NoTypeInformation -Path $OutFile
Write-Output "Wrote $OutFile"
