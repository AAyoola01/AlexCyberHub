import csv, sys
from collections import Counter

def main(fp):
    c = Counter()
    with open(fp, newline='', encoding='utf-8', errors='ignore') as f:
        r = csv.DictReader(f)
        for row in r:
            eid = row.get('Id') or row.get('EventID') or ''
            if str(eid) == '4625':
                c['failed_logon'] += 1
            elif str(eid) == '4624':
                c['successful_logon'] += 1
    total = sum(c.values())
    print(f"Parsed: {total} events")
    for k, v in c.items():
        print(f"{k}: {v}")

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python parse_windows_security_logs.py <export.csv>")
        sys.exit(1)
    main(sys.argv[1])
