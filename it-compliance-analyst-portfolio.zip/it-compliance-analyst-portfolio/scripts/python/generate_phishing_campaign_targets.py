import csv, sys

def main(roster_csv, exclusions_csv, out_csv):
    recent = set()
    with open(exclusions_csv, newline='', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            recent.add(row['email'].strip().lower())
    with open(roster_csv, newline='', encoding='utf-8') as f, open(out_csv, 'w', newline='', encoding='utf-8') as o:
        r = csv.DictReader(f)
        w = csv.DictWriter(o, fieldnames=r.fieldnames)
        w.writeheader()
        for row in r:
            if row['email'].strip().lower() not in recent:
                w.writerow(row)
    print(f"Wrote {out_csv}")

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: python generate_phishing_campaign_targets.py roster.csv recent_training.csv targets.csv")
        sys.exit(1)
    main(sys.argv[1], sys.argv[2], sys.argv[3])
