import csv, sys

REQUIRED = ["id","title","owner","impact","likelihood","score"]

def main(fp):
    errors = []
    with open(fp, newline='', encoding='utf-8') as f:
        r = csv.DictReader(f)
        line = 1
        for row in r:
            line += 1
            for k in REQUIRED:
                if not row.get(k):
                    errors.append(f"Line {line}: Missing {k}")
            try:
                imp = int(row.get("impact",0))
                lik = int(row.get("likelihood",0))
                score = int(row.get("score",0))
                if imp * lik != score:
                    errors.append(f"Line {line}: Score should equal impact*likelihood ({imp}*{lik}={imp*lik}) != {score}")
            except ValueError:
                errors.append(f"Line {line}: impact/likelihood/score must be integers")
    if errors:
        print("Errors:")
        print("
".join(errors))
        sys.exit(2)
    print("Risk register OK")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python risk_register_quality_check.py risk_register.csv")
        sys.exit(1)
    main(sys.argv[1])
