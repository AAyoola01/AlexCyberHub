# Security Policy

**Reporting a Vulnerability**  
If you discover a vulnerability in this repository's sample code, please open a private issue or email the maintainer.
Do **not** disclose publicly until a fix or mitigation has been documented.

**Scope**  
This repository contains **sample** governance, risk, and compliance (GRC) artifacts intended for demonstration and interviews.
Do not deploy without tailoring to your organization's environment, laws, and risk appetite.

**Coordinated Disclosure**  
We aim for responsible disclosure with a 90-day window, where applicable.
