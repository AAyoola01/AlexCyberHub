# Contributing

1. Fork the repo and create a feature branch.
2. Make changes with clear commit messages referencing the artifact (e.g., policy/standard).
3. Open a PR and include: purpose, scope, and any framework mappings (NIST, CIS, ISO).
4. For policy changes, attach a redline diff and stakeholder sign-offs.
