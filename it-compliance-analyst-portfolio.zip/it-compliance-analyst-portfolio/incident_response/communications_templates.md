# Communications Templates

**Executive Update (Internal):**  
- What happened, impact, actions, ETA, next update time.

**Employee Notice (Internal):**  
- Do/Don't, how to report suspicious activity.

**Public Statement (External):**  
- Acknowledgement, scope, steps taken, where to get help.
