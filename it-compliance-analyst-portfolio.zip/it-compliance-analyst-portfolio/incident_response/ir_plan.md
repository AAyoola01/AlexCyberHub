# Incident Response Plan

**Roles:** Incident Commander, Comms Lead, Forensics, Legal/Privacy, IT Ops, Business Owner.  
**Severity:** Sev1 (High impact), Sev2 (Moderate), Sev3 (Low).  
**Tooling:** Ticketing, SIEM/EDR, evidence preserve, secure comms channel.

**Playbook Linkage:** See `playbooks/` for common scenarios.

**Reporting:** Notify leadership and legal per thresholds; breach notifications per law.
