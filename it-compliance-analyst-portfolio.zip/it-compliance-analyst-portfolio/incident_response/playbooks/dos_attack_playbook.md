# Playbook: Denial of Service (DoS/DDoS)

- Coordinate with ISP/CDN for filtering and rate-limiting.
- Activate WAF rules; scale out as needed.
- Prioritize critical public services; comms plan for stakeholders.
