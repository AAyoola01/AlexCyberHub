# Playbook: Ransomware

**Detect:** EDR alerts, mass encryption, ransom notes.  
**Contain:** Network isolation, disable SMB, block IOCs.  
**Eradicate:** Clean images; verify backups not compromised.  
**Recover:** Restore from immutable backups; staged bring-up.  
**Comms:** Executive updates; law enforcement; public statement if needed.  
**KPIs:** MTTD, MTTR, % assets reimaged, data loss.
