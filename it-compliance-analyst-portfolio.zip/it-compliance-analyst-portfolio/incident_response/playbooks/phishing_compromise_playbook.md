# Playbook: Phishing / Account Compromise

1. **Identify:** Suspicious login, inbox rule creation, MFA fatigue, user report.
2. **Contain:** Force sign-out, reset creds, revoke tokens, disable forwarding.
3. **Eradicate:** Remove malicious rules; scan endpoints; examine OAuth consents.
4. **Recover:** Re-enable after validation; user coaching.
5. **Hunt:** Search tenant for similar IOCs.
6. **Report:** Metrics to SSC; consider privacy implications.
