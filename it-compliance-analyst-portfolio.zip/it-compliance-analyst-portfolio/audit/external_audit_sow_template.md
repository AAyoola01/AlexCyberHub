# Statement of Work – External Security Assessment (Template)

**Services:** Risk assessment, technical testing (scope defined), policy review, and report with remediation plan.  
**Deliverables:** Executive summary, detailed findings, evidence, and retest.  
**Assumptions:** Limited production disruption; test window; POC contacts.  
**Acceptance:** Criteria and sign-off by Security Lead and CIO.
