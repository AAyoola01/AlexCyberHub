# Internal Audit Plan (Cybersecurity & IT Governance)

**Objective:** Provide independent assurance over control design and operating effectiveness.

**Scope 2025:** Access management, patch & vulnerability, log management, backup/recovery, vendor risk.

**Approach:** Walkthroughs → Evidence sampling → Test of controls → Reporting → Remediation tracking.
