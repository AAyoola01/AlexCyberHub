# Audit Report (Template)

**Executive Summary**  
- Overall rating: (Effective / Needs Improvement / Ineffective)

**Findings & Ratings**  
| ID | Title | Severity | Root Cause | Recommendation | Owner | Due |
|----|-------|----------|------------|----------------|-------|-----|

**Management Action Plan**  
- Actions, owners, milestones.

**Appendices**  
- Scope, sampling, evidence list.
