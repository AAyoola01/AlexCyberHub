# Sample Phishing Templates

1. **Password Expiry Alert** – Link to spoofed portal; measure MFA prompts.
2. **Missed Package Delivery** – Track mobile clicks vs desktop.
3. **HR Policy Update** – Require acknowledgment; watch for credential entry.
