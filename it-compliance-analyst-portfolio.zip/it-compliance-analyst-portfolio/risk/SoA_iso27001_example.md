# ISO 27001 Statement of Applicability (Excerpt)

| Control | Implemented | Rationale | Evidence |
|--------|--------------|-----------|----------|
| A.5.1 Policies for information security | Yes | Policy suite approved by SSC | policy_catalog.md, approvals |
| A.5.23 Information security for use of cloud services | Partial | Hybrid cloud adoption in progress | Vendor assessments, configs |
