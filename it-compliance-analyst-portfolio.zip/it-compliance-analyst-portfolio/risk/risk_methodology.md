# Risk Methodology

- **Identification:** Sources include audits, incidents, threat intel, and assessments.
- **Analysis:** Likelihood (1–5) × Impact (1–5); consider existing controls.
- **Treatment:** Avoid, Reduce, Transfer, Accept.
- **Monitoring:** Quarterly review; SSC approves acceptances > threshold.
- **Registers:** Use the CSV template; maintain owners, due dates, and status.
