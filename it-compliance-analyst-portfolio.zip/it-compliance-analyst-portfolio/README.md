# IT Compliance Analyst Portfolio

A practical, portfolio-style repository showcasing **IT governance, cybersecurity compliance, risk management, audit readiness, security awareness, and incident response** capabilities — tailored for a municipal environment (e.g., City IT).

> ✅ Includes policies, procedures, frameworks mappings (NIST CSF, CIS Controls, ISO 27001), audit checklists, risk register, incident playbooks, awareness training, and automation scripts (PowerShell/Python).

## Contents
- `docs/` – Policies, standards, procedures, frameworks mappings, audit plans, templates.
- `risk/` – Risk register template and methodology.
- `audit/` – Internal audit plan, checklists, SOW and report templates.
- `incident_response/` – Incident Response Plan and playbooks (ransomware, phishing, DoS), PIR template.
- `kpis_metrics/` – Security KPIs/metrics and dashboard requirements.
- `legal_regulatory/` – Municipal-focused compliance landscape (BC-centric example).
- `mappings/` – NIST↔CIS mappings, NIST CSF control matrix.
- `scripts/` – Automation for evidence collection, log parsing, and QA on risk data.
- `training/` – Awareness plan, phishing content and runbooks.
- `SIEM/` – Sample KQL queries (can adapt for Sentinel/Defender/Splunk SPL equivalents).

## How to Use
1. **Tailor** the policies and procedures to your environment (scope, roles, tools, laws).
2. **Map** controls to your authoritative framework (NIST CSF, CIS v8, ISO 27001:2022).
3. **Run** scripts in `scripts/` to demonstrate audit evidence collection and detection use-cases.
4. **Present**: Walk interviewers through governance, risk, and incident scenarios using these artifacts.

## Quick Start
```bash
git init
git add .
git commit -m "Initial commit: IT Compliance Analyst portfolio"
git branch -M main
# Create a new GitHub repo first, then:
git remote add origin <YOUR_REPO_URL>
git push -u origin main
```

## Attribution
This portfolio is authored by a candidate with municipal IT experience, CompTIA Security+, and CISA-in-progress. Artifacts are **illustrative** and should be validated before production use.
