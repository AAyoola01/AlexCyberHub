# Security Steering Committee - Terms of Reference

**Mandate:** Oversee cybersecurity risk posture, approve policies, review metrics and audit findings.

**Membership:** CIO/Dir IT (Chair), Security Lead, IT Ops Lead, Privacy Officer, Internal Audit, Business Reps.

**Cadence:** Monthly or quarterly; ad-hoc for major incidents.

**Inputs:** Risk register heatmap, KRIs/KPIs, open audit issues, major projects, exceptions.

**Outputs:** Decisions on risk treatment, policy approvals, funding asks, action items with owners & due dates.
