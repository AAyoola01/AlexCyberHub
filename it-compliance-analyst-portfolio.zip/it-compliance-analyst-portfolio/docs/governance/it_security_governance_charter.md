# IT Security Governance Charter

**Purpose:** Establish decision rights, accountability, and oversight for information security across the organization.

**Scope:** All business units, information systems, and data assets.

**Principles:**
- Risk-based prioritization aligned to organizational objectives.
- Defense-in-depth and least privilege.
- Compliance with applicable laws and standards.

**Bodies & Roles:**
- **Security Steering Committee (SSC):** Provides strategic oversight, approves policies and risk acceptance.
- **CISO/IS Lead:** Owns program, reports to executive sponsor; accountable for IR, risk, and compliance.
- **IT Ops & Dev Leads:** Implement controls, provide evidence, and report exceptions.
- **Internal Audit:** Independent assurance function.

**Decision Rights:** Policy approval, risk acceptance, exception handling, budget prioritization.

**Performance:** Quarterly metrics on risk, incidents, patch SLAs, and awareness completion.
