# Meeting Minutes – Security Steering Committee

**Date/Time:**  
**Attendees:**  
**Agenda:**  

## 1. Metrics Review
- Patch compliance:
- Vulnerability backlog:
- Phishing failure rate:

## 2. Risk Register Highlights
- Top risks & treatment updates

## 3. Audit Items
- Open findings status

## 4. Policy Decisions
- Approvals / Exceptions

## 5. Projects & Funding
- Decisions / Next steps

**Action Items:**  
| Item | Owner | Due | Status |
|------|-------|-----|--------|
