# Access Control Policy

**Principles:** Least privilege, need-to-know, role-based access (RBAC), and separation of duties.

**Requirements:**
- Joiner-Mover-Leaver (JML) process with <24h> leaver deprovision.
- MFA required for privileged accounts and remote access.
- Quarterly access reviews for critical systems.
- Service accounts: documented owners, non-interactive, rotated secrets.

**Evidence & Metrics:** Access review reports, privileged access approvals, JML audit logs.
