# Log Management Policy

**Scope:** Security event logs from endpoints, servers, applications, network, and cloud services.

**Requirements:**
- Centralize logs in SIEM with time sync (NTP), tamper resistance, and retention (e.g., 365 days).
- Monitor critical events (auth, privilege use, configuration change, malware).
- Documented use cases and alerts; periodic tuning.
