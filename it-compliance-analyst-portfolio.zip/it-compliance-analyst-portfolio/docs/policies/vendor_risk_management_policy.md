# Vendor Risk Management Policy

**Scope:** Third parties processing organizational data or providing critical services.

**Requirements:**
- Security due diligence proportional to risk (questionnaires, SOC 2/ISO certs, pen test attestation).
- Data Processing Agreements and right-to-audit clauses.
- Ongoing monitoring and annual reassessment for critical vendors.
