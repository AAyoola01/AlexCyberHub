# Data Classification & Handling Policy

**Classes:** Public, Internal, Confidential, Restricted.  
**Handling:** Encryption at rest & in transit for Confidential/Restricted.  
**Labeling:** Systems and documents must reflect classification.  
**Retention:** Per records management schedule and legal hold requirements.
