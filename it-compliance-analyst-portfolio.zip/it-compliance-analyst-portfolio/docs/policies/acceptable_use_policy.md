# Acceptable Use Policy (AUP)

**Purpose:** Define acceptable use of organizational IT resources.  
**Applies to:** All employees, contractors, and third parties.

**Key Requirements:**
- Use systems for authorized business purposes.
- Prohibit unauthorized software and data exfiltration.
- No sharing of credentials or MFA tokens.
- Follow data handling per classification policy.
- Monitoring and logging are in effect with no expectation of privacy beyond law.

**Enforcement:** Violations may lead to disciplinary action and/or legal remedies.
