# Incident Response Policy

**Objective:** Ensure timely detection, response, communication, and recovery from security incidents.

**Phases:** Prepare → Identify → Contain → Eradicate → Recover → Lessons Learned.

**Requirements:**
- 24x7 contact tree and on-call rotation.
- Severity classification & SLAs (e.g., Sev1 triage within 30 minutes).
- Mandatory post-incident review within 5 business days.
- Regulated breach notification as required by law.

**Testing:** Annual tabletop and technical exercises.
