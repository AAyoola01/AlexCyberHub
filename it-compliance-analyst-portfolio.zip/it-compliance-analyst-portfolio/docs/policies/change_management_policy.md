# Change Management Policy

**Purpose:** Govern changes to production systems to reduce risk.

**Requirements:**
- Change tickets with risk/impact, backout plan, approvals.
- Segregation for emergency changes; post-change review.
- Maintenance windows and stakeholder comms.
