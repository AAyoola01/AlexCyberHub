# Secure Configuration Baseline – Windows

- CIS benchmark-aligned GPOs: audit policies, credential guard, SMB signing.
- Disable legacy protocols (SMBv1, NTLM where possible).
- Local admin management with LAPS/Entra Local Admin Password Solution.
