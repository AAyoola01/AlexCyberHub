# Password & Authentication Standard

- Enforce MFA for all users; phishing-resistant MFA for admins where feasible.
- Passwords: min length 14; block common/compromised.
- No password reuse with 24 history where supported.
- Service accounts use vaulted long random secrets or certificates.
