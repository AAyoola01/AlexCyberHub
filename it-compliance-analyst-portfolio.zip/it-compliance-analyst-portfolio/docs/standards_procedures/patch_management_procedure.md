# Patch Management Procedure

- **Cadence:** Monthly patch cycle; out-of-band for zero-days.
- **Testing:** Staging validation before production.
- **Change Control:** CAB approval for high-impact updates.
- **Evidence:** Patch compliance report by device group.
