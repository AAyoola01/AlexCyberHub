# Backup & Recovery Standard

- 3-2-1 strategy with immutable/offline copy.
- Backups encrypted and tested quarterly.
- Recovery Time Objective (RTO) and Recovery Point Objective (RPO) documented per system.
