# Phishing Simulation Runbook

**Cycle:** Quarterly (or monthly for high-risk groups).  
**Steps:** Target list → Template selection → Pre-brief managers → Launch → Triage clicks → Micro-training → Report to SSC.  
**KPIs:** Click rate, report rate, time-to-report, repeat offenders trend.
