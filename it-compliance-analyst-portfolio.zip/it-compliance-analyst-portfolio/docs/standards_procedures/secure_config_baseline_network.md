# Secure Configuration Baseline – Network

- AAA via TACACS+/RADIUS, unique admin accounts, MFA where supported.
- Disable unused services/ports; secure SNMPv3.
- Syslog to SIEM; config backups with integrity checks.
