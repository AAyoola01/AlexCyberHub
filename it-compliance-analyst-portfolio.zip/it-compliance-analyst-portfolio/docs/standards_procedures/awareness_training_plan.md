# Security Awareness & Education Plan

- **Onboarding:** 30-minute mandatory module + policy attestations.
- **Monthly Nudges:** Short topics tied to observed risks (smishing, MFA fatigue).
- **Quarterly:** Phishing simulations + metrics reporting.
- **Role-Based:** Admin secure operations; developers secure SDLC.
